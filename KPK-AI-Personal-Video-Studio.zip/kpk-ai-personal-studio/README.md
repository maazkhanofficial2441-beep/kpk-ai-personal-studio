# KPK AI — Personal Video Studio

A private Next.js app with:
- One-owner sign-in through Supabase Auth (no public sign-up UI).
- Server-side owner email allowlist on every protected page and API.
- Prompt studio templates and prompt enhancement.
- Text-to-video generation and prediction status polling through Replicate.
- Responsive dark dashboard.

## Important setup

This is a working app scaffold, not a hosted website. You must connect your own Supabase project and a video model provider. Video generation may incur provider charges. The exact model input fields vary by model.

### 1. Install

```bash
npm install
cp .env.example .env.local
```

Fill `.env.local` with your Supabase URL, publishable key, owner email, Replicate API token, and selected model owner/name. Never expose `REPLICATE_API_TOKEN` in a `NEXT_PUBLIC_` variable or commit `.env.local`.

### 2. Create the only owner account

1. Create a Supabase project.
2. In Supabase Authentication settings, turn off public sign-ups.
3. In Supabase Authentication > Users, create/invite your own email account and set its password.
4. Set `OWNER_EMAIL` to exactly that account's email.
5. Add your deployed site URL to Supabase Auth's allowed redirect/site URL settings if required.

The app checks the authenticated email against `OWNER_EMAIL` on the server. Do not share the owner password.

### 3. Configure video generation

1. Create a Replicate account and API token.
2. Choose a text-to-video model from its model catalog.
3. Copy the model owner and model name into `REPLICATE_MODEL_OWNER` and `REPLICATE_MODEL_NAME`.
4. Read that model's input schema. Set `REPLICATE_PROMPT_FIELD` to the correct prompt field (often `prompt`).
5. Put any required model inputs in the dashboard's JSON options, or set defaults in `REPLICATE_EXTRA_INPUT_JSON` (currently the dashboard accepts request options directly).

Model schemas vary. The app sends `{ input: { [promptField]: prompt, ...options } }` to the official model predictions endpoint. If the chosen model needs an image URL or other required fields, add a secure upload flow before using image-to-video. This starter currently implements text-to-video, not image upload.

### 4. Run locally

```bash
npm run dev
```

Open http://localhost:3000.

### 5. Deploy online

Deploy this repository to a Next.js-compatible host such as Vercel. Add every `.env.local` variable in the host's project environment settings, then deploy. Keep the repository private if it contains any private project details; secrets must only live in environment variables.

## Security notes

- The Replicate token is only used in server route handlers.
- Every video API request verifies the Supabase user and owner allowlist.
- There is no sign-up page.
- Use a strong unique password and enable available account security protections.
- Configure provider spending limits/alerts where available. Never paste API tokens into chat or browser code.

## Current feature boundary

The prompt builder works without a paid model. Real video generation requires valid provider credentials, an active provider account, a compatible model, and possibly paid usage. 4K output is not guaranteed; it depends on the selected model.
