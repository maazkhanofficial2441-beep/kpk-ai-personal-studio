import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "KPK AI — Personal Video Studio",
  description: "Private AI video and prompt studio"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}