import { NextResponse } from "next/server";
import { getOwner } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getOwner();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return NextResponse.json({ error: "Provider is not configured." }, { status: 503 });

  const { id } = await context.params;
  if (!/^[a-zA-Z0-9_-]{5,100}$/.test(id)) return NextResponse.json({ error: "Invalid request ID." }, { status: 400 });

  const response = await fetch(`https://api.replicate.com/v1/predictions/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${token}` }, cache: "no-store"
  });
  const data = await response.json();
  if (!response.ok) return NextResponse.json({ error: data.detail || "Could not retrieve prediction." }, { status: response.status });
  return NextResponse.json(data);
}