import { NextResponse } from "next/server";
import { getOwner } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const user = await getOwner();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const token = process.env.REPLICATE_API_TOKEN;
  const owner = process.env.REPLICATE_MODEL_OWNER;
  const model = process.env.REPLICATE_MODEL_NAME;
  const promptField = process.env.REPLICATE_PROMPT_FIELD || "prompt";
  if (!token || !owner || !model) {
    return NextResponse.json({ error: "Video provider is not configured. Add the Replicate token and model owner/name to server environment variables." }, { status: 503 });
  }

  try {
    const body = await request.json();
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (!prompt || prompt.length > 5000) return NextResponse.json({ error: "Prompt is required and must be under 5,000 characters." }, { status: 400 });
    const options = body.options && typeof body.options === "object" && !Array.isArray(body.options) ? body.options : {};
    const input = { ...options, [promptField]: prompt };

    const response = await fetch(`https://api.replicate.com/v1/models/${encodeURIComponent(owner)}/${encodeURIComponent(model)}/predictions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Prefer: "wait=1" },
      body: JSON.stringify({ input }),
      cache: "no-store"
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data.detail || data.error || "Provider rejected the request. Check model inputs and account limits." }, { status: response.status });
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Invalid request or provider response." }, { status: 500 });
  }
}