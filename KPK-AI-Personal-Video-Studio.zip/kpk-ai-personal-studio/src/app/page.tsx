import { redirect } from "next/navigation";
import { getOwner } from "@/lib/auth";
import Studio from "@/components/Studio";

export default async function Home() {
  const user = await getOwner();
  if (!user) redirect("/login");
  return <Studio email={user.email ?? ""} />;
}