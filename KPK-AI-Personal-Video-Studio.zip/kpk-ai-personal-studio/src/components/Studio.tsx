"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Prediction = { id: string; status: string; output?: string | string[] | null; error?: string | null; urls?: { web?: string } };

const examples = [
  { label: "3D Cartoon", text: "A polished 3D animated scene, expressive characters, consistent character design, cinematic lighting, smooth camera movement." },
  { label: "Islamic Nature", text: "A peaceful cinematic landscape with mountains, a flowing waterfall, soft morning light, respectful Islamic atmosphere, no text, no logos." },
  { label: "Village Story", text: "A beautiful rural village in Pakistan, warm golden-hour lighting, emotional storytelling, realistic details, cinematic camera movement." },
  { label: "Cinematic Short", text: "A visually striking cinematic short film, dramatic but natural lighting, detailed environment, smooth motion, professional composition." }
];

export default function Studio({ email }: { email: string }) {
  const [tab, setTab] = useState<"video"|"prompt">("video");
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("Cinematic");
  const [ratio, setRatio] = useState("9:16");
  const [extra, setExtra] = useState("");
  const [prediction, setPrediction] = useState<Prediction|null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  function buildPrompt() {
    const full = `${prompt.trim()}\nStyle: ${style}. Aspect ratio: ${ratio}. High-quality motion, coherent scene, clean composition.`;
    setPrompt(full);
    setMessage("Prompt prepared. Review it before generating.");
  }

  async function generate() {
    if (!prompt.trim()) { setMessage("Please write a video prompt first."); return; }
    setBusy(true); setMessage("Submitting your video request…"); setPrediction(null);
    try {
      let modelOptions = {};
      if (extra.trim()) modelOptions = JSON.parse(extra);
      const res = await fetch("/api/video", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, options: modelOptions })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not start generation.");
      setPrediction(data);
      setMessage("Request accepted. You can check its status below.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Something went wrong.");
    } finally { setBusy(false); }
  }

  async function checkStatus() {
    if (!prediction?.id) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/video/${encodeURIComponent(prediction.id)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Status check failed.");
      setPrediction(data);
      setMessage(`Video status: ${data.status}`);
    } catch(e) { setMessage(e instanceof Error ? e.message : "Status check failed."); }
    finally { setBusy(false); }
  }

  async function logout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    window.location.href = "/login";
  }

  const outputUrl = Array.isArray(prediction?.output) ? prediction?.output[0] : prediction?.output;

  return <main className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark small">K</div><div><b>KPK AI</b><small>PERSONAL STUDIO</small></div></div>
      <div className="side-label">WORKSPACE</div>
      <button className={`nav-item ${tab==="video"?"active":""}`} onClick={()=>setTab("video")}>▣ <span>AI Video Generator</span></button>
      <button className={`nav-item ${tab==="prompt"?"active":""}`} onClick={()=>setTab("prompt")}>✧ <span>Prompt Studio</span></button>
      <div className="sidebar-bottom"><div className="private-pill">● PRIVATE ACCESS</div><small>{email}</small><button className="logout" onClick={logout}>Sign out ↗</button></div>
    </aside>
    <section className="main-area">
      <header className="topbar"><div><p className="eyebrow">YOUR CREATIVE SPACE</p><h2>{tab==="video"?"AI Video Generator":"Prompt Studio"}</h2></div><span className="online"><i/> Secure workspace</span></header>
      {tab==="video" ? <div className="content-grid">
        <section className="panel editor">
          <div className="panel-heading"><div><span className="step">01</span><h3>Describe your video</h3></div><span className="tag">TEXT TO VIDEO</span></div>
          <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Describe the scene, subject, movement, camera angle, lighting and mood…" rows={8}/>
          <div className="field-row">
            <div><label>Visual style</label><select value={style} onChange={e=>setStyle(e.target.value)}><option>Cinematic</option><option>3D Cartoon</option><option>Realistic</option><option>Anime-inspired</option><option>Documentary</option></select></div>
            <div><label>Aspect ratio</label><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>16:9</option><option>1:1</option></select></div>
          </div>
          <div className="button-row"><button className="secondary" onClick={buildPrompt}>✧ Enhance prompt</button><button className="primary" disabled={busy} onClick={generate}>{busy?"Working…":"Generate video →"}</button></div>
          <p className="hint">Generation uses your configured provider account. Usage may be billed by that provider.</p>
        </section>
        <section className="panel settings">
          <div className="panel-heading"><div><span className="step">02</span><h3>Model settings</h3></div></div>
          <label>Extra model options (JSON)</label>
          <textarea className="json-area" rows={5} value={extra} onChange={e=>setExtra(e.target.value)} placeholder={'{"duration":5,"aspect_ratio":"9:16"}'}/>
          <p className="hint">These options depend on the exact model you configure. Leave blank to use its defaults.</p>
          <div className="notice"><b>Model compatibility</b><p>Video models use different input fields. Set the model name and prompt field in your server environment, then match options to that model’s schema.</p></div>
          <div className="suggestions"><b>Quick prompt ideas</b>{examples.map(x=><button key={x.label} onClick={()=>setPrompt(x.text)}>{x.label}<span>↗</span></button>)}</div>
        </section>
        <section className="panel result-panel">
          <div className="panel-heading"><div><span className="step">03</span><h3>Your generation</h3></div>{prediction&&<span className="tag">{prediction.status.toUpperCase()}</span>}</div>
          {!prediction ? <div className="empty-preview"><div className="play-icon">▶</div><b>Your video will appear here</b><p>Write a prompt and start a generation.</p></div> :
            <div className="result-content">
              <p><b>Request ID:</b> <code>{prediction.id}</code></p>
              <p><b>Status:</b> {prediction.status}</p>
              {outputUrl && <video controls playsInline src={outputUrl} className="video-result"/>}
              {prediction.error && <p className="error">{prediction.error}</p>}
              {prediction.urls?.web && <a href={prediction.urls.web} target="_blank" rel="noreferrer">Open provider task ↗</a>}
              <button className="secondary" disabled={busy} onClick={checkStatus}>↻ Check status</button>
            </div>}
          {message && <p className="status-message">{message}</p>}
        </section>
      </div> : <div className="prompt-page">
        <section className="panel">
          <div className="panel-heading"><div><span className="step">✧</span><h3>Prompt idea builder</h3></div></div>
          <p className="muted">Choose a starting point, then edit it into your own scene. This tool prepares prompts; it does not generate the video by itself.</p>
          <div className="prompt-cards">{examples.map(x=><button key={x.label} onClick={()=>setPrompt(x.text)}><b>{x.label}</b><span>{x.text}</span></button>)}</div>
          <label>Your prompt</label><textarea rows={8} value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Write your idea here…"/>
          <button className="primary" onClick={buildPrompt}>Enhance prompt</button>
          <button className="secondary copy" onClick={()=>navigator.clipboard.writeText(prompt)}>Copy prompt</button>
        </section>
      </div>}
      <footer>© 2026 KPK AI · Personal use only · Keep API secrets private</footer>
    </section>
  </main>;
}