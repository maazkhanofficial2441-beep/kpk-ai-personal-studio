"use client";

import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { setError(error.message); setBusy(false); return; }
    window.location.href = "/";
  }

  return <main className="login-wrap">
    <form className="login-card" onSubmit={submit}>
      <div className="brand-mark">K</div>
      <p className="eyebrow">PRIVATE WORKSPACE</p>
      <h1>KPK <span>AI</span></h1>
      <p className="muted">Your personal video creation studio</p>
      <label>Email address</label>
      <input type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="Your owner email" />
      <label>Password</label>
      <input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your password" />
      {error && <p className="error">{error}</p>}
      <button className="primary full" disabled={busy}>{busy ? "Signing in…" : "Sign in privately"}</button>
      <p className="tiny">Private access only · Public registration is disabled</p>
    </form>
  </main>;
}